

-Oceano (Owned and Operated by LilRoo, previously known as Cybox) EULA
 


*You ARE permitted to:

-Make youtube videos about Oceano/including Oceano.

-Feature Oceano on your website, although you MUST link to the offical Oceano page and not any other download source.




*You ARE permitted to with LilRoo's EXPLICIT PERMISSION:
-Edit the shaders and share it with the internet. Note: Must be more than just value edits and be something meaningfull.
-Use Oceano's code.




*You are NOT permitted to:

-Claim any of Oceano's code as your own.

-Edit the shader then claim it as your own.

-Make money off of Oceano (This does not mean Youtube videos or such, but instead redistributing the shader for your own profit).
-Use different links that do not direct to the CurseForge Oceano download page.